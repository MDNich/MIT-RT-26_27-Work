import numpy as np
A = np.array([7.2193,5.3309e8])
E = np.array([58.7107e3,146.674e3])
N = np.array([1.1125,2.0825])
CHI = np.array([.554,.9479])
RGAS=8.314462618
DENSITY_LOSS=(1575.-1165.)/1575.
